# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## Instructions

1-this Landing Page written using (HTML ,CSS, JS).  

2-if you add any number of new sections or deleted one , it will correct navigation menu automaticaly.

3-scrolling is in a smooth way  in the my landing page.

4-active state in the section when the element is in the viewport.

- Developed by Abdullah Amin. -